import pyshark
import re
import base64
import urllib.parse
import requests
import json
from functools import wraps
import os
from asyncio.proactor_events import _ProactorBasePipeTransport


def silence_event_loop_closed(func):
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        try:
            return func(self, *args, **kwargs)
        except RuntimeError as e:
            if str(e) != 'Event loop is closed':
                raise

    return wrapper


_ProactorBasePipeTransport.__del__ = silence_event_loop_closed(_ProactorBasePipeTransport.__del__)


def find_layer(cap, protocol_name='http'):
    for i, layer in enumerate(cap.layers):
        if layer._layer_name == protocol_name:
            return i


limit = lambda s: s if len(s) < 100 else s[:100] + '...'


def abstract(s, content_type):
    if content_type == 1:
        s = s.split('&')
        abstr = []
        for line in s:
            pos = line.find('=')
            value = line[pos + 1:]
            try:
                value = urllib.parse.unquote(value)
                abstr.append(base64.b64decode(value.encode()).decode())
            except:
                continue
        if len(abstr) > 0:
            return limit(' '.join(abstr))
        else:
            return ''
    elif content_type == 3:
        pattern = re.findall(r'\-[A-Za-z0-9]+  Content-Disposition: .*?; name=\".*?\"(; filename=\".*?\")?  (Content\-Type: .*?)?  (.*?)  -', s)
        res = [_[2] for _ in pattern]
        return limit(' '.join(res))
    else:
        test_json = json.loads(s)
        abstr = []
        for key, value in test_json:
            try:
                value = urllib.parse.unquote(value)
                abstr.append(base64.b64decode(value.encode()).decode())
            except:
                continue
        if len(abstr) > 0:
            return limit(' '.join(abstr))
        else:
            return ''

sample_payload_number = 10

class routes:
    def __init__(self, route_name, method):
        self.route, self.method = route_name, method
        self.suffix, self.body = [], []
        self.danger, self.view = 0, 0
        self.map, self.cookie = {}, {}

    def __str__(self) -> str:
        res = '''类型: %s  路由: %s  危险指数: %s 访问量:%d \n''' % (self.method, self.route, self.danger, self.view)
        if self.method == 'GET':
            self.suffix = list(set(self.suffix))
            for i in range(min(sample_payload_number, len(self.suffix))):
                res += '载荷样例%d: 载荷数据包编号: frame.number == %s cookie: %s\n%s?%s \n' % (i + 1, self.map[self.suffix[i]], self.cookie[self.map[self.suffix[i]]], self.route, limit(self.suffix[i]))
        else:
            self.body = list(set(self.body))
            for i in range(min(sample_payload_number, len(self.body))):
                res += '载荷样例%d: 载荷数据包编号: frame.number == %s cookie: %s\n %s?%s\n\n%s' % (i + 1, self.map[self.body[i]], self.cookie[self.map[self.body[i]]], self.route, limit(self.body[i][0]), limit(self.body[i][1]))
                abstr = abstract(self.body[i][1], self.body[i][2])
                if len(abstr) > 0:
                    res += '\n摘要: %s' % abstr
                res += '\n%s\n' % ('=' * 90)
        return res


route_dict = {}
danger_dict = {"flag": 10, "eval": 10, "assert": 5, "select": 5, "<?php": 10, "__subclasses__": 10}


def judge(payload):
    res = 0
    for key, value in danger_dict.items():
        if key in payload:
            res += value
    return res


def judge_encode(payload):
    payload = urllib.parse.unquote(payload)
    res = 0
    res += judge(payload)
    try:
        res += judge(base64.b64decode(payload.encode()).decode())
    except:
        pass
    return res


def judge_field(payload, content_type=0):
    res = 0
    if content_type == 0:
        res += judge_encode(payload)
    elif content_type == 1:
        payload = payload.split('&')
        for line in payload:
            key, value = line.split('=')
            res += judge_encode(value)
    elif content_type == 2:
        test_json = json.loads(payload)
        for key, value in test_json:
            res += judge_encode(value)
    else:
        pattern = re.findall(r'\-[A-Za-z0-9]+  Content-Disposition: .*?; name=\".*?\"(; filename=\".*?\")?  (Content\-Type: .*?)?  (.*?)  -', payload)
        for _ in pattern:
            res += judge_encode(_[2])
    return res


def add_get_route(number, url, cookie):
    url = url.split('?')
    route = url[0]
    suffix = url[1] if len(url) > 1 else ''
    if route_dict.get((route, 'GET')) == None:
        route_dict[(route, 'GET')] = routes(route, 'GET')
    route_dict[(route, 'GET')].suffix.append(suffix)
    route_dict[(route, 'GET')].map[suffix] = number
    route_dict[(route, 'GET')].cookie[number] = cookie
    route_dict[(route, 'GET')].danger += judge(suffix)
    route_dict[(route, 'GET')].view += 1


def add_post_route(number, url, content_type, body, cookie):
    url = url.split('?')
    route = url[0]
    suffix = url[1] if len(url) > 1 else ''
    if route_dict.get((route, 'POST')) == None:
        route_dict[(route, 'POST')] = routes(route, 'POST')
    route_dict[(route, 'POST')].body.append((suffix, body, content_type))
    route_dict[(route, 'POST')].map[(suffix, body, content_type)] = number
    route_dict[(route, 'POST')].cookie[number] = cookie
    route_dict[(route, 'POST')].danger += (judge_field(suffix, content_type) + judge_field(body, content_type))
    route_dict[(route, 'POST')].view += 1


def grep_get_cap(filename):
    caps = pyshark.FileCapture(filename, display_filter='http.request.method==GET')
    for cap in caps:
        pos = find_layer(cap)
        cookie = cap.layers[pos]._all_fields.get('http.cookie')
        add_get_route(cap.number, cap.layers[pos]._all_fields['http.request.uri'], cookie)
    caps.close()


type_list = {'application/x-www-form-urlencoded': 1, 'application/json': 2, 'multipart/form-data': 3}


def grep_post_cap(filename):
    caps = pyshark.FileCapture(filename, display_filter='http.request.method==POST')
    for cap in caps:
        pos = find_layer(cap)
        url = cap.layers[pos]._all_fields['http.request.uri']
        cookie = cap.layers[pos]._all_fields.get('http.cookie')
        try:
            content_type = cap.layers[pos]._all_fields['http.content_type']
            content_type = 'multipart/form-data' if 'multipart/form-data' in content_type else content_type 
            body = cap.layers[pos]._all_fields['http.file_data']
            add_post_route(int(cap.number), url, type_list[content_type], body, cookie)
        except:
            add_get_route(int(cap.number), url, cookie)
    caps.close()


def key_value2dict(payload):
    payload = payload.split('&')
    res = {}
    for every_payload in payload:
        pos = every_payload.find('=')
        key, value = every_payload[:pos], every_payload[pos + 1:]
        res[key] = urllib.parse.unquote(value)
    return res


def gen_payload(filename, number):
    caps = pyshark.FileCapture(filename, display_filter='frame.number == %d' % (number))
    cap = caps[0]
    caps.close()
    pos = find_layer(cap)
    method = cap.layers[pos]._all_fields['http.request.method']
    if method == 'GET':
        try:
            path = cap.layers[pos]._all_fields['http.request.uri.path']
            query = cap.layers[pos]._all_fields['http.request.uri.query']
            params = key_value2dict(query)
            return '''r = requests.get(ip + '%s', params=%s)''' % (path, params)
        except:
            uri = cap.layers[pos]._all_fields['http.request.uri']
            return '''r = requests.get(ip + '%s')''' % uri
    else:
        uri = cap.layers[pos]._all_fields['http.request.uri']
        params = ''
        content_type = cap.layers[pos]._all_fields['http.content_type']
        body = cap.layers[pos]._all_fields['http.file_data']
        if content_type == 'application/x-www-form-urlencoded':
            data = key_value2dict(body)
            return '''r = requests.post(ip + '%s', params=%s, data=%s)''' % (uri, params, data)
        elif content_type == "application/json":
            return '''r = requests.post(ip + '%s', params=%s, json=%s)''' % (uri, params, body)
        elif 'multipart/form-data' in content_type:
            pattern = re.findall(r'\-[A-Za-z0-9]+  Content-Disposition: .*?; name=\"(.*?)\"(\; filename=\".*?\")?  (Content\-Type: .*?)?  (.*?)  \-', body)
            res = '''files = {\n'''
            for group in pattern:
                name, file_name, contenttype, content = group[0], group[1], group[2], group[3] 
                if file_name != '':
                    file_name = '"%s"' % re.findall(r'\; filename=\"(.*?)\"', file_name)[0]
                else:
                    file_name = 'None'
                if contenttype != '':
                    contenttype = '"%s"' % contenttype.split('Content-Type: ')[1]
                else:
                    contenttype = 'None'
                content = '"%s"' % content
                res += '''    "%s": (%s, %s, %s),\n''' % (name ,file_name, content, contenttype)
            res += '''}\nr = requests.post(ip + '%s', files=files)''' % (uri)
            return res
    


def gen_tcp_steam_payload(filename, number):
    caps = pyshark.FileCapture(filename, display_filter='tcp.stream eq %d && http' % (number))
    res = '''session = requests.session()\n'''
    for cap in caps:
        res += gen_payload(filename, int(cap.number)) + '\n'
    caps.close()
    return res.replace('r = requests.', 'r = session.')


def print_cap(mode=0):
    os.system("cls")
    if mode == 0:
        print_route = sorted(route_dict.items(), key=lambda x: x[1].view, reverse=True)
        for key, item in print_route:
            print(item)
    elif mode == 1:
        print_route = sorted(route_dict.items(), key=lambda x: x[1].danger, reverse=True)
        for key, item in print_route:
            print(item)
    elif mode == 2:
        print_route = sorted(route_dict.items(), key=lambda x: x[1].view, reverse=True)
        for key, item in print_route:
            if item.method == 'GET':
                print(item)
    if mode == 3:
        print_route = sorted(route_dict.items(), key=lambda x: x[1].danger, reverse=True)
        for key, item in print_route:
            if item.method == 'POST':
                print(item)
    

def cap_choose(filename):
    while True:
        id = int(input("输入数据包编号: "))
        if id == -1:
            return
        print(gen_payload(filename, id))


def stream_choose(filename):
    while True:
        id = int(input("输入tcp流编号: "))
        if id == -1:
            return
        print(gen_tcp_steam_payload(filename, id))

MENU = '''
[*] 选择模式
mode = 0: 按照访问量排序
mode = 1: 按照危险程度排序
mode = 2: 只看get包,按照访问量排序
mode = 3: 只看post包,按照危险度排序
mode = 4: 复现数据包payload
mode = 5: 复现数据流payload
'''
def menu(filename):
    print(MENU)
    while True:
        mode = int(input("输入模式: "))
        if mode < 4:
            print_cap(mode)
        elif mode == 4:
            cap_choose(filename)
        else:
            stream_choose(filename)

def release(filename):
    grep_get_cap(filename)
    grep_post_cap(filename)
    print_cap()
    menu(filename)


def test(filename):
    # grep_post_cap(filename)
    # print(gen_payload(filename, 4))
    print(gen_tcp_steam_payload(filename, 0))


if __name__ == '__main__':
    filename = '20210717_1257.pcap'
    release(filename)
    # todo  菜单，多种筛选,get,post筛选，访问量筛选，危险度筛选，小于值筛选
